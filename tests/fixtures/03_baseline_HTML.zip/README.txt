Synthetic split-HTML export. Expected equivalent to baseline JSON.
